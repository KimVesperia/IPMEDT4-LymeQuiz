function myButton1() {
    document.getElementById("resultaat1").innerHTML = "1. Klinkt erop. Probeer het nog eens.";
    document.getElementById("ql1").disabled = true;
    document.getElementById("bt1").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt1").style.color = "red";
    document.getElementById("resultaat1").style.color = "red";
    document.getElementById("bt2").style.color = "black";
    document.getElementById("bt3").style.color = "black";
    document.getElementById("bt4").style.color = "black";
    document.getElementById("bt2").style.boxShadow = "inherit";
    document.getElementById("bt3").style.boxShadow = "inherit";
    document.getElementById("bt4").style.boxShadow = "inherit";
}

function myButton2() {
    document.getElementById("resultaat1").innerHTML = "1. Leuke naam ervoor. Probeer het nog eens.";
    document.getElementById("ql1").disabled = true;
    document.getElementById("bt2").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt2").style.color = "red";
    document.getElementById("resultaat1").style.color = "red";
    document.getElementById("bt1").style.color = "black";
    document.getElementById("bt3").style.color = "black";
    document.getElementById("bt4").style.color = "black";
    document.getElementById("bt1").style.boxShadow = "inherit";
    document.getElementById("bt3").style.boxShadow = "inherit";
    document.getElementById("bt4").style.boxShadow = "inherit";
}

function myButton3() {
    document.getElementById("resultaat1").innerHTML = "1. Goed! De ziekte van Lyme wordt veroorzaakt door de bacterie Borrelia burgdorferi.";
    document.getElementById("ql1").disabled = false;
    document.getElementById("bt3").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt3").style.color = "green";
    document.getElementById("resultaat1").style.color = "green";
    document.getElementById("bt1").style.color = "black";
    document.getElementById("bt2").style.color = "black";
    document.getElementById("bt4").style.color = "black";
    document.getElementById("bt1").style.boxShadow = "inherit";
    document.getElementById("bt2").style.boxShadow = "inherit";
    document.getElementById("bt4").style.boxShadow = "inherit";
}

function myButton4() {
    document.getElementById("resultaat1").innerHTML = "1. Waar zal het naar proeven? Probeer het nog eens.";
    document.getElementById("ql1").disabled = true;
    document.getElementById("bt4").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt4").style.color = "red";
    document.getElementById("resultaat1").style.color = "red";
    document.getElementById("bt1").style.color = "black";
    document.getElementById("bt2").style.color = "black";
    document.getElementById("bt3").style.color = "black";
    document.getElementById("bt1").style.boxShadow = "inherit";
    document.getElementById("bt2").style.boxShadow = "inherit";
    document.getElementById("bt3").style.boxShadow = "inherit";
}

function restart() {
  location.reload(true);
}

function question1() {
  document.getElementById("question1Box").style.display = "none";
  document.getElementById("question2Box").style.display = "inherit";
  document.getElementById("q1").style.display = "none";
  document.getElementById("q2").style.display = "inherit";
}

function myButton5() {
    document.getElementById("resultaat2").innerHTML = "2. Goed! De ziekte van Lyme kun je alleen via de beet van een besmette teek oplopen. De teek wordt besmet als hij bloed zuigt bij kleine (knaag)dieren of vogels die de bacterie bij zich kunnen dragen. Wanneer een teek later bloed van mensen zuigt, kan de bacterie op de mens overgedragen worden. Ongeveer 1 op de 5 teken draagt de bacterie bij zich.";
    document.getElementById("ql2").disabled = false;
    document.getElementById("bt5").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt5").style.color = "green";
    document.getElementById("resultaat2").style.color = "green";
    document.getElementById("bt6").style.color = "black";
    document.getElementById("bt7").style.color = "black";
    document.getElementById("bt8").style.color = "black";
    document.getElementById("bt6").style.boxShadow = "inherit";
    document.getElementById("bt7").style.boxShadow = "inherit";
    document.getElementById("bt8").style.boxShadow = "inherit";
}

function myButton6() {
    document.getElementById("resultaat2").innerHTML = "2. Enge beesten. Probeer het nog eens.";
    document.getElementById("ql2").disabled = true;
    document.getElementById("bt6").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt6").style.color = "red";
    document.getElementById("resultaat2").style.color = "red";
    document.getElementById("bt5").style.color = "black";
    document.getElementById("bt7").style.color = "black";
    document.getElementById("bt8").style.color = "black";
    document.getElementById("bt5").style.boxShadow = "inherit";
    document.getElementById("bt7").style.boxShadow = "inherit";
    document.getElementById("bt8").style.boxShadow = "inherit";
}

function myButton7() {
    document.getElementById("resultaat2").innerHTML = "2. Het jeukt wel.. Probeer het nog eens.";
    document.getElementById("ql2").disabled = true;
    document.getElementById("bt7").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt7").style.color = "red";
    document.getElementById("resultaat2").style.color = "red";
    document.getElementById("bt5").style.color = "black";
    document.getElementById("bt6").style.color = "black";
    document.getElementById("bt8").style.color = "black";
    document.getElementById("bt5").style.boxShadow = "inherit";
    document.getElementById("bt6").style.boxShadow = "inherit";
    document.getElementById("bt8").style.boxShadow = "inherit";
}

function myButton8() {
    document.getElementById("resultaat2").innerHTML = "2. Ze doen je niets als je ze met rust laat. Probeer het nog eens.";
    document.getElementById("ql2").disabled = true;
    document.getElementById("bt8").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt8").style.color = "red";
    document.getElementById("resultaat2").style.color = "red";
    document.getElementById("bt5").style.color = "black";
    document.getElementById("bt6").style.color = "black";
    document.getElementById("bt7").style.color = "black";
    document.getElementById("bt5").style.boxShadow = "inherit";
    document.getElementById("bt6").style.boxShadow = "inherit";
    document.getElementById("bt7").style.boxShadow = "inherit";
}

function myButton9() {
    document.getElementById("resultaat3").innerHTML = "3. Kan een symptoom zijn, maar alleen daarvoor ga je niet naar de dokter. Probeer het nog eens.";
    document.getElementById("ql3").disabled = true;
    document.getElementById("bt9").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt9").style.color = "red";
    document.getElementById("resultaat3").style.color = "red";
    document.getElementById("bt10").style.color = "black";
    document.getElementById("bt11").style.color = "black";
    document.getElementById("bt12").style.color = "black";
    document.getElementById("bt10").style.boxShadow = "inherit";
    document.getElementById("bt11").style.boxShadow = "inherit";
    document.getElementById("bt12").style.boxShadow = "inherit";
}

function myButton10() {
    document.getElementById("resultaat3").innerHTML = "3. Kan een symptoom zijn, maar alleen daarvoor ga je niet naar de dokter. Probeer het nog eens.";
    document.getElementById("ql3").disabled = true;
    document.getElementById("bt10").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt10").style.color = "red";
    document.getElementById("resultaat3").style.color = "red";
    document.getElementById("bt9").style.color = "black";
    document.getElementById("bt11").style.color = "black";
    document.getElementById("bt12").style.color = "black";
    document.getElementById("bt9").style.boxShadow = "inherit";
    document.getElementById("bt11").style.boxShadow = "inherit";
    document.getElementById("bt12").style.boxShadow = "inherit";
}

function myButton11() {
    document.getElementById("resultaat3").innerHTML = "3. Goed! Er zijn verschillende vormen van de huiduitslag bij besmetting met de Lymebacterie. De huiduitslag kan er uit zien als een ring, maar ook als een egaal gekleurde vlek.";
    document.getElementById("ql3").disabled = false;
    document.getElementById("bt11").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt11").style.color = "green";
    document.getElementById("resultaat3").style.color = "green";
    document.getElementById("bt9").style.color = "black";
    document.getElementById("bt10").style.color = "black";
    document.getElementById("bt12").style.color = "black";
    document.getElementById("bt9").style.boxShadow = "inherit";
    document.getElementById("bt10").style.boxShadow = "inherit";
    document.getElementById("bt12").style.boxShadow = "inherit";
}

function myButton12() {
    document.getElementById("resultaat3").innerHTML = "3. Kan een symptoom zijn, maar alleen daarvoor ga je niet naar de dokter. Probeer het nog eens.";
    document.getElementById("ql3").disabled = true;
    document.getElementById("bt12").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt12").style.color = "red";
    document.getElementById("resultaat3").style.color = "red";
    document.getElementById("bt9").style.color = "black";
    document.getElementById("bt10").style.color = "black";
    document.getElementById("bt11").style.color = "black";
    document.getElementById("bt9").style.boxShadow = "inherit";
    document.getElementById("bt10").style.boxShadow = "inherit";
    document.getElementById("bt11").style.boxShadow = "inherit";
}

function question2() {
  document.getElementById("question2Box").style.display = "none";
  document.getElementById("question3Box").style.display = "inherit";
  document.getElementById("q2").style.display = "none";
  document.getElementById("q3").style.display = "inherit";
}

function myButton13() {
    document.getElementById("resultaat4").innerHTML = "4. Zoveel!? Probeer het nog eens.";
    document.getElementById("ql4").disabled = true;
    document.getElementById("bt13").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt13").style.color = "red";
    document.getElementById("resultaat4").style.color = "red";
    document.getElementById("bt14").style.color = "black";
    document.getElementById("bt15").style.color = "black";
    document.getElementById("bt16").style.color = "black";
    document.getElementById("bt14").style.boxShadow = "inherit";
    document.getElementById("bt15").style.boxShadow = "inherit";
    document.getElementById("bt16").style.boxShadow = "inherit";
}

function myButton14() {
    document.getElementById("resultaat4").innerHTML = "4. Was het maar waar. Probeer het nog eens.";
    document.getElementById("ql4").disabled = true;
    document.getElementById("bt14").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt14").style.color = "red";
    document.getElementById("resultaat4").style.color = "red";
    document.getElementById("bt13").style.color = "black";
    document.getElementById("bt15").style.color = "black";
    document.getElementById("bt16").style.color = "black";
    document.getElementById("bt13").style.boxShadow = "inherit";
    document.getElementById("bt15").style.boxShadow = "inherit";
    document.getElementById("bt16").style.boxShadow = "inherit";
}

function myButton15() {
    document.getElementById("resultaat4").innerHTML = "4. Bijna. Probeer het nog eens.";
    document.getElementById("ql4").disabled = true;
    document.getElementById("bt15").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt15").style.color = "red";
    document.getElementById("resultaat4").style.color = "red";
    document.getElementById("bt13").style.color = "black";
    document.getElementById("bt14").style.color = "black";
    document.getElementById("bt16").style.color = "black";
    document.getElementById("bt13").style.boxShadow = "inherit";
    document.getElementById("bt14").style.boxShadow = "inherit";
    document.getElementById("bt16").style.boxShadow = "inherit";
}

function myButton16() {
    document.getElementById("resultaat4").innerHTML = "4. Goed! Het  hangt heel erg af van het gebied, de begroeiing, het aantal besmette knaagdieren en de tekendichtheid. In Nederland is gemiddeld één op de vijf teken (20%) besmet met de bacterie die de ziekte van Lyme kan veroorzaken (Borrelia burgdorferi).<br><br>Goed gedaan je bent klaar met niveau 1!";
    document.getElementById("ql4").disabled = false;
    document.getElementById("bt16").style.boxShadow = "rgba(0, 0, 0, 0.39) 0px 0px 0px 0.2rem";
    document.getElementById("bt16").style.color = "green";
    document.getElementById("resultaat4").style.color = "green";
    document.getElementById("bt13").style.color = "black";
    document.getElementById("bt14").style.color = "black";
    document.getElementById("bt15").style.color = "black";
    document.getElementById("bt13").style.boxShadow = "inherit";
    document.getElementById("bt14").style.boxShadow = "inherit";
    document.getElementById("bt15").style.boxShadow = "inherit";
}

function question3() {
  document.getElementById("question3Box").style.display = "none";
  document.getElementById("question4Box").style.display = "inherit";
  document.getElementById("q3").style.display = "none";
  document.getElementById("q4").style.display = "inherit";
}
